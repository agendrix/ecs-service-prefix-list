"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.__test__ = void 0;
const aws_sdk_1 = __importDefault(require("aws-sdk"));
const handler = async (event) => {
    const prefixList = await fetchPrefixList(process.env['PREFIX_LIST_ID']);
    const params = formatParams(event, prefixList);
    modifyPrefixList(params);
};
const fetchPrefixList = async (prefixListId) => {
    var _a;
    const result = await ec2Client().describeManagedPrefixLists({ PrefixListIds: [prefixListId] }).promise();
    const prefixList = (_a = result.PrefixLists) === null || _a === void 0 ? void 0 : _a.pop();
    if (prefixList) {
        return {
            id: prefixList.PrefixListId,
            version: prefixList.Version
        };
    }
    else {
        throw new Error(`An error occurred while handling event. The prefixList ${prefixListId} was not found in region ${process.env.REGION}.`);
    }
};
const formatParams = (event, prefixList) => {
    const params = { PrefixListId: prefixList.id, CurrentVersion: prefixList.version };
    const cidr = fetchCidr(event);
    if (event.detail.lastStatus === "PENDING") {
        console.log(`Adding cidr ${cidr}, in prefixtList ${prefixList.id}`);
        return (Object.assign(Object.assign({}, params), { AddEntries: [{
                    Cidr: cidr,
                    Description: event.detail.taskArn
                }] }));
    }
    else if (event.detail.lastStatus === "STOPPED") {
        console.log(`Removing cidr ${cidr}, in prefixtList ${prefixList.id}`);
        return (Object.assign(Object.assign({}, params), { RemoveEntries: [{ Cidr: cidr }] }));
    }
    else {
        throw new Error(`An error occurred while forwarding event ${event.id}. The task state ${event.detail.lastStatus} is not recognized by this function.`);
    }
};
const fetchCidr = (event) => {
    const eni = event.detail.attachments.find(attachment => attachment.type === "eni");
    const privateIp = eni.details.find(detail => detail.name === "privateIPv4Address");
    return `${privateIp.value}/32`;
};
const modifyPrefixList = async (params) => {
    try {
        await ec2Client().modifyManagedPrefixList(params).promise();
    }
    catch (e) {
        if (e.code === "IncorrectState") {
            console.log(`Retrying request in 100ms: ${e.message}`);
            setTimeout(modifyPrefixList, 100, params);
        }
        else {
            throw new Error(`An error occurred while handling event. Error ${JSON.stringify(e)}`);
        }
    }
};
const ec2Client = () => (new aws_sdk_1.default.EC2(({ region: process.env.REGION })));
exports.handler = handler;
exports.__test__ = {
    handler,
    formatParams
};
