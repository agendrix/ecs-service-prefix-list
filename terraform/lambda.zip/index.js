"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.__test__ = void 0;
const aws_sdk_1 = __importDefault(require("aws-sdk"));
const handler = async (event) => {
    const ec2 = new aws_sdk_1.default.EC2(({ region: process.env.REGION }));
    const params = formatParams(event);
    const response = await ec2.modifyManagedPrefixList(params).promise();
    if (response.$response.retryCount !== 0) {
        throw new Error(`An error occurred while handling event ${event.id}. Error code: ${response.$response.httpResponse.statusCode}, Error message: ${response.$response.httpResponse.body.toString}`);
    }
};
const fetchCidr = (event) => {
    const eni = event.detail.attachments[0];
    const privateIp = eni.details.find.find(detail => detail.name === "privateIPv4Address");
    return `${privateIp.value}/32`;
};
const formatParams = (event) => {
    const params = { PrefixListId: process.env['PREFIX_LIST_ID'] };
    const cidr = fetchCidr(event);
    if (event.detail.lastStatus === "PENDING") {
        return (Object.assign(Object.assign({}, params), { AddEntries: [{
                    Cidr: cidr,
                    Description: event.detail.taskArn
                }] }));
    }
    else if (event.detail.lastStatus === "STOPPED") {
        return (Object.assign(Object.assign({}, params), { RemoveEntries: [{ Cidr: cidr }] }));
    }
    else {
        throw new Error(`An error occurred while forwarding event ${event.id}. The task state ${event.detail.lastStatus} is not recognized by this function.`);
    }
};
exports.handler = handler;
exports.__test__ = {
    handler,
    formatParams
};
